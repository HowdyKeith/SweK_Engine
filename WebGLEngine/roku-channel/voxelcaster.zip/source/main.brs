' VoxelCaster — minimal sideloaded Roku channel for the SweK Engine.
' Deep-link it via ECP:  POST /launch/dev?contentId=<urlenc>&mediaType=<mp4|hls|image>
' It plays an HTTP video stream, or shows an image full-screen. No UI/store needed.
sub Main(args as dynamic)
    url = ""
    mtype = "mp4"
    if args <> invalid
        if args.contentId <> invalid then url = args.contentId
        if args.url <> invalid then url = args.url
        if args.mediaType <> invalid then mtype = args.mediaType
    end if
    if url = "" then
        ShowMessage("VoxelCaster ready — launch it with a url")
        return
    end if
    lu = LCase(url)
    if LCase(mtype) = "image" or Instr(1, lu, ".jpg") > 0 or Instr(1, lu, ".jpeg") > 0 or Instr(1, lu, ".png") > 0 then
        ShowImage(url)
    else
        PlayVideo(url, mtype)
    end if
end sub

sub PlayVideo(url as string, mtype as string)
    port = CreateObject("roMessagePort")
    screen = CreateObject("roVideoScreen")
    screen.SetMessagePort(port)
    content = { Stream: { url: url }, StreamFormat: mtype, Title: "VoxelCaster", PlayStart: 0 }
    screen.SetContent(content)
    screen.Show()
    while true
        msg = Wait(0, port)
        if Type(msg) = "roVideoScreenEvent" then
            if msg.isScreenClosed() then return
        end if
    end while
end sub

sub ShowImage(url as string)
    port = CreateObject("roMessagePort")
    canvas = CreateObject("roImageCanvas")
    canvas.SetMessagePort(port)
    canvas.SetLayer(0, { Color: "#000000", CompositionMode: "Source" })
    canvas.SetLayer(1, { Url: url })
    canvas.Show()
    while true
        msg = Wait(0, port)
        if Type(msg) = "roImageCanvasEvent" then
            if msg.isScreenClosed() then return
        end if
    end while
end sub

sub ShowMessage(text as string)
    port = CreateObject("roMessagePort")
    canvas = CreateObject("roImageCanvas")
    canvas.SetMessagePort(port)
    canvas.SetLayer(0, { Color: "#101820", CompositionMode: "Source" })
    canvas.SetLayer(1, { Text: text, TextAttrs: { Color: "#FFFFFF", Font: "Medium", HAlign: "HCenter", VAlign: "VCenter" } })
    canvas.Show()
    Wait(8000, port)
end sub
